package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class SignUpPage {

    public void showSignUpPage(Stage stage) {
        // Top Panel (Logo and Slogan)
        VBox topPanel = new VBox();
        topPanel.setStyle("-fx-background-color: #FF9900;");
        topPanel.setPadding(new Insets(20, 20, 10, 20)); 
        topPanel.setAlignment(Pos.CENTER);
        topPanel.setSpacing(5);

        // Logo
        ImageView logoView = new ImageView(new Image(getClass().getResourceAsStream("/images/BookedInLogo.png")));
        logoView.setFitWidth(80);
        logoView.setPreserveRatio(true);

        // Slogan
        Label slogan = new Label("Fuel Your Fire, One Story at a Time!");
        slogan.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #333333;");
        
        // Add the logo and slogan to the top panel
        topPanel.getChildren().addAll(logoView, slogan);

        // Sign-Up Form Panel
        VBox formPanel = new VBox();
        formPanel.setPadding(new Insets(20, 20, 15, 20)); 
        formPanel.setAlignment(Pos.TOP_CENTER);
        formPanel.setSpacing(10); 
        formPanel.setStyle("-fx-background-color: #FFFFFF; -fx-border-radius: 15; -fx-background-radius: 15;");

        // Sign-Up Label
        Label signUpLabel = new Label("Sign Up");
        signUpLabel.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");

        // Input Fields
        TextField firstNameField = new TextField();
        firstNameField.setPromptText("First Name");
        TextField lastNameField = new TextField();
        lastNameField.setPromptText("Last Name");
        TextField asuIdField = new TextField();
        asuIdField.setPromptText("ASU ID");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        firstNameField.setMaxWidth(280);
        lastNameField.setMaxWidth(280);
        asuIdField.setMaxWidth(280);
        passwordField.setMaxWidth(280);

        // Role Selection (CheckBoxes)
        CheckBox buyerCheckBox = new CheckBox("Buyer");
        CheckBox sellerCheckBox = new CheckBox("Seller");

        HBox roleSelection = new HBox(10, buyerCheckBox, sellerCheckBox);
        roleSelection.setAlignment(Pos.CENTER);

        // Sign-Up Button
        Button signUpButton = new Button("Join Now →");
        signUpButton.setStyle("-fx-background-color: #8B0000; -fx-text-fill: white; -fx-padding: 8 16;");
        signUpButton.setMaxWidth(200);

        // Message label for feedback
        Label messageLabel = new Label();
        messageLabel.setStyle("-fx-text-fill: red; -fx-font-size: 12px;");

        // Sign-up button action
        signUpButton.setOnAction(e -> {
            String asuId = asuIdField.getText().trim();
            String password = passwordField.getText().trim();
            boolean isBuyer = buyerCheckBox.isSelected();
            boolean isSeller = sellerCheckBox.isSelected();

            // Basic validation
            if (asuId.isEmpty() || password.isEmpty()) {
                messageLabel.setText("ASU ID and Password are required.");
            } else if (!isBuyer && !isSeller) {
                messageLabel.setText("Please select at least one role.");
            } else {
                // Save user details to file
                saveUserToFile(asuId, password, isBuyer, isSeller);
                messageLabel.setStyle("-fx-text-fill: green;");
                messageLabel.setText("Registration successful! Please proceed to login.");
            }
        });

        // Hyperlink for login page
        Hyperlink loginLink = new Hyperlink("Already have an account? Login");
        loginLink.setStyle("-fx-text-fill: #8B0000;");
        loginLink.setPadding(new Insets(3, 0, 0, 0)); 
        loginLink.setOnAction(e -> {
            LoginPageFX loginPage = new LoginPageFX();
            loginPage.start(stage); 
        });

        // Add elements to the form panel
        formPanel.getChildren().addAll(
            signUpLabel, firstNameField, lastNameField, asuIdField, passwordField,
            new Label("Select Role(s):"), roleSelection, signUpButton, messageLabel, loginLink
        );

        // Main layout (combining the top panel and form panel)
        VBox mainLayout = new VBox();
        mainLayout.getChildren().addAll(topPanel, formPanel);
        mainLayout.setSpacing(5);
        mainLayout.setAlignment(Pos.TOP_CENTER);
        mainLayout.setStyle("-fx-background-color: #FF9900;");
        mainLayout.setPadding(new Insets(10, 20, 10, 20)); 

        Scene signUpScene = new Scene(mainLayout, 400, 650); 
        stage.setScene(signUpScene);
        stage.setTitle("BookedIn - Sign Up");
        stage.show();
    }

    // This is where the saving for users.txt takes place
    private void saveUserToFile(String asuId, String password, boolean isBuyer, boolean isSeller) {
        String buyerRole = isBuyer ? "true" : "false";
        String sellerRole = isSeller ? "true" : "false";
        String adminRole = "false"; // Default admin role to false since we are not trying to include that functionality

        String userDetails = String.format("%s,%s,%s,%s,%s", asuId, password, buyerRole, sellerRole, adminRole);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("src/users.txt", true))) {
            writer.write(userDetails);
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error writing to users.txt: " + e.getMessage());
        }
    }
}
